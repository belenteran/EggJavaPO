
package javaapplication7;

import PackageCadena.Cadena;
import Servicio.ServiceCadena;

public class JavaApplication7 {


    public static void main(String[] args) {
        
       Cadena obj = new Cadena("Murcielago");
       ServiceCadena serv = new ServiceCadena();
        System.out.println(obj.getLongitud());
        System.out.println("La palabra es:: "+ obj.getPalabra());
        System.out.println("La cantidad de vocales son:: " + serv.mostrarVocales(obj)); 
        serv.invertirFrases(obj);
        System.out.println("La cantidad de veces que se repite " + serv.vecesRepetido("r", obj));
        serv.unirFrases("hola ", obj);
        serv.reemplazar(obj, "e");
       
    }
    
}
