

package Servicio;

import PackageCadena.Cadena;
import java.util.Scanner;

 
public class ServiceCadena {
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    
    public int mostrarVocales(Cadena obj)
    {
        int vocales=0;
        String v;
        for (int i=0;i<obj.getLongitud();i++)
        {
            v=obj.getPalabra().substring(i,i+1);
            if(v.equalsIgnoreCase("a")||v.equalsIgnoreCase("e")||v.equalsIgnoreCase("i")||v.equalsIgnoreCase("o")||v.equalsIgnoreCase("u")) 
            {
                vocales++;
            }
        }
        return vocales;
    }
    public void invertirFrases(Cadena obj)
    {
        
        String invertida="";
        for (int i=obj.getLongitud();i>0;i--)
        { 
            invertida+=obj.getPalabra().substring(i-1,i);
           
        } 
        System.out.println("LA PALABRA INVERTIDA ES " + invertida);
    }
    public int vecesRepetido(String letra,Cadena obj)
    {
        int vocales=0;
        String v;
        for (int i=0;i<obj.getLongitud();i++)
        {
            v=obj.getPalabra().substring(i,i+1);
            if(v.equalsIgnoreCase(letra)) 
            {
                vocales++;
            }
        }
        return vocales;
    }
    public boolean compararLongitud(String frase,Cadena obj)
    {   
        return obj.getLongitud()>frase.length();
    }
    public void unirFrases(String frase,Cadena obj)
    {   
        System.out.println("La frase concatenada es:: " + frase+obj.getPalabra());
    }
    public void reemplazar(Cadena obj,String letra)
    {   
        
        String v,r="";
        for (int i=0;i<obj.getLongitud();i++)
        {
            v=obj.getPalabra().substring(i,i+1);
            
            if(v.equalsIgnoreCase("a")) 
            {
                r+=letra;
            }
            else
            {          
            r+=v;
            }
        }
        
        System.out.println("La palabra modificada es:: " + r);
        
    }
    
}
